# Question-bank schema

Store each Part 2 cue card as its own Markdown note under `雅思口语语料库/题库/Part 2/`. Store Part 1 and Part 3 questions in topic notes under their respective folders.

Use YAML fields when the source provides enough information:

```yaml
---
type: ielts-speaking-question
part: 2
topic: people
season: "2026-09"
status: new
source: "user-import"
source_url: ""
last_practised:
practice_count: 0
tags:
  - ielts/speaking/part2
---
```

Allowed `status` values: `new`, `practising`, `review`, `mastered`.

## Part 2 body

```markdown
# Describe ...

## Cue card

You should say:

- ...

and explain ...

## Related Part 3

- ...

## My material

## Practice history
```

Preserve the source question wording. Normalize typography and obvious copy/paste noise, but do not silently rewrite the question. Deduplicate exact and near-identical questions; retain variant wording in the same note when useful. Add `source_url` only when known—never invent provenance.

When importing large batches, update `雅思口语语料库/题库索引.md` with counts and links by part/topic/season.
